#include "libre.hpp"

void calcu(std::string cadena)
{
	std::cout << cadena <<std::endl;
}
