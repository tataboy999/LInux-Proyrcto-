#include <stdio.h>
#include <iostream>

void calcu(std::string cadena);
