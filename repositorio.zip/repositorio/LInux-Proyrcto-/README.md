# Calculadora 
## Instrucciones de programacion 


*Calculadora*


 
* primero deveras descragael el archivo "tareafina.sh"
* segundo ir a la termina e dar permiso al archivo "tareafina.sh"
* luego correr el archivo "tareafinal"

Enlace al repositorio: https://github.com/profedm/linux_ucg

### Lista de comandos básicos:

* *git clone [repositorio]*: Copiar repositorio en equipo
* *git pull*: Actualizar el repositorio
* *git add [fuente]*: Añadir modificaciones al repositorio
* *git commit -m [comentario]*: Comentar los cambios
* *git push origin master*: Subir los cambios al repositorio

### Documentacion de readme: 
Enlace: https://help.github.com/es/github/writing-on-github/basic-writing-and-formatting-syntax
