#!/bin/bash

echo "Intalador"

cd tareafinal
mkdir build
cd build
cmake ..
make
./calcu
